# Importar las librerías
import math
import random
import numpy as np 
import redis 
import time 

tau = 3.0
# Definición de los estados
def respond(Yk, Uk):
   return 0.79798315*Yk + 0.18809689*Uk + 0.33851755
   ## en el return en teoria va la funcion generada 

estados = []
Y=20.0
for k in range(101):
  Y=round(Y,1)
  estados.append(Y)
  Y=Y+0.1
print(estados)

"""**Acciones**"""

# Definición de las acciones
acciones = []
A = 20.0
for k in range(21):
  A=round(A,1)
  acciones.append(A)
  A=A+0.5
# acciones = [round(x*0.1,1) for x in range(11)]
print(acciones)

"""**Recompensas**"""

import pandas as pd
import matplotlib.pyplot as plt

# Definición de las recompensas
def reward(temp):
        if ((temp > 23.5)and(temp < 24.5)):
            return 1.0
        else:
            return 0.0

temps = [(x * 0.1)+20 for x in range(100)]
R = [reward(x) for x in temps]
fig=plt.figure(figsize=(12, 4))

plt.scatter(temps, R)
plt.xlabel('Temperature')
plt.ylabel('Reward')
plt.title('Reward vs. Temperature')

def Ambiente(ei,ai):
  y=respond(ai,ei)
  R_i1=reward(y)
  return y,R_i1

# Configuración de los parámetros gamma y alfa para el Q-Learning
gamma = 0.75
alpha = 0.9
# Inicialización de los valores Q
Q = np.array(np.zeros([101,21]))

# Implementación del proceso de Q-Learning
for i in range(10000):
    estado_actual = np.random.randint(0,101)
    accion_realizable = np.random.randint(0,21)
    temp_siguiente,Ri = Ambiente(estados[estado_actual], acciones[accion_realizable])
    estado_siguiente =  estados.index(round(temp_siguiente,1))
    TD = Ri + gamma*Q[estado_siguiente, np.argmax(Q[estado_siguiente,])]- Q[estado_actual, accion_realizable]
    Q[estado_actual, accion_realizable] = Q[estado_actual, accion_realizable] + alpha*TD

"""Podemos echarle un vistazo ejecutando todo el código que hemos implementado hasta ahora e ingresando las siguientes dos instrucciones en la consola:"""

print("Q-Values:")
print(Q)


# temp=30

# def dinamica():
#   global temp
#   estado_act =  estados.index(round(temp,1))
#   acc_sig = np.argmax(Q[estado_act,])
#   temp = respond(temp, acciones[acc_sig])
#   print(acc_sig)
#   print(acciones[acc_sig])
#   print(temp)
# dinamica()

# # Hacer la función final que devolverá la ruta óptima
# def ruta(inicio, fin):
#     ruta = [inicio]
#     siguiente = inicio
#     while (siguiente != fin):
#         estado_inicial = def_de_estados[inicio]
#         siguiente = np.argmax(Q[estado_inicial,])
#         siguiente = mapeo_de_estados[siguiente]
#         ruta.append(siguiente)
#         inicio = siguiente
#     return ruta

"""Probar la ruta para ir de E a G.

**Tarea 2**

1. Comente el programa completo y de una descripción del problema resuelto con el método de Q-Learning.
2. Para tener un algoritmo funcional, cómo debería configurar la matriz de recompensas para ir por una ruta óptima por ejemplo desde E a G.
3. Pruebe con diferentes valores de gamma y alpha y comente los resultados obtenidos.
4. Como obtener una ruta que obligue a pasar por una ruta intermedia ?.
5. Comente claramente la función ruta(inicio, fin).
6. Comente como funciona np.argmax(Q[estado_inicial,]), que esta devolviendo en cada ejecución.
7. Construir igualmente un archivo .ipynb con la versión desarrollada por cada uno de Uds., asignarle valores a la matriz de recompensas de acuerdo a rutas que Uds., establecieron y comentar los resultados.
8. El reporte final se debe subir al classroom de la materia

**Tarea 3**

Explicar el código de la mejora 1 (código anterior). Ejecutar diferentes opciones de ruta y concluir sobre la respuesta generado por el algoritmo. Para los códigos que han venido implementando (16 estados) y con un ambiente 4x5, implementar esta mejora. Crear un reporte y subirlo al classroom de la clase.

**Tarea 4**

Como en la tarea anterior, explicar el codigo de la función mejor_ruta(). Adecuar la matriz de recompensas de acuerdo a la idea de evitar pasar por algunos sitios y también optimizando o privilegiando el paso por otros sitios, para ésto que modfificaciones hay que realizar, explicar claramente porque ?. Finalizar los dos códigos que han venido realizando y crear un reporte completo de este ejercicio y subirlos al classroom de la clase.
"""