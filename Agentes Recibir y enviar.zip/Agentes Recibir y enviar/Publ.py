# publisher.py
import redis
import random
import time, json 

r = redis.Redis(host='192.168.16.217', port=6379, db=0)

temp = 0.0
action = 0.0

for i in range(100):
    if (i == 0):
        action = 20.0
        json_datos = json.dumps({"id": 1, "valor": action})
    if ((i >=1) and (i < 50)):
        action = 20.0
        json_datos = json.dumps({"id":0, "valor": action})
    if ((i >=50) and (i < 80)):
        action = 30.0
        json_datos = json.dumps({"id": 0, "valor": action})
    if ((i >=80) and (i < 100)):
        action = 25.0
        json_datos = json.dumps({"id": 0,"valor": action})        
    r.publish('canal9-0', json_datos)
    print(json_datos)
    time.sleep(1)    