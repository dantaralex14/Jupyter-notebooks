# Dantar Alejandro Ortiz Vega 6-D
# Jose Ramon Preciado Torres 6-D

# En este codigo de python que pasaremos luego a una libreta de jupyter, en este codigo se definen ciertos aspecotos como el vector
# de estados resultantes de el ascensor asi como las acciones que el ascensor hara como subir, bajar, detenerse,abrir y cerrar puertas
# icluyendo claro el sistema de recompensas que mejorare para la entrega posterior que sera la siguiente semana con el algoritmo del Q-learning

import numpy as np
import time
import random

# Definimos la clase del ascensor
class Ascensor:
    def __init__(self):
        self.lugar = 1  # Piso inicial
        self.direccion = 0  # Detenido
        self.movimiento = 0  # Detenido
        self.solicitud_interna = [0, 0, 0, 0, 0]  # No hay solicitudes internas
        self.solicitud_externa = [0, 0, 0, 0, 0]  # No hay solicitudes externas
        self.tiempo_espera_externa = [0, 0, 0, 0, 0]  # Tiempo de espera de solicitudes externas
        self.puertas_abiertas = False  # Estado inicial de las puertas
# Definimos los movimientos del ascensor 
    def mover_arriba(self):
        if self.lugar < 5:
            self.lugar += 1
            self.movimiento = 1
            self.direccion = 1

    def mover_abajo(self):
        if self.lugar > 1:
            self.lugar -= 1
            self.movimiento = 1
            self.direccion = -1

    def parar(self):
        self.movimiento = 0

    def abrir_puertas(self):
        # Solo abre las puertas si hay solicitudes internas o externas en el piso en el que se encuentre
        if self.solicitud_interna[self.lugar - 1] == 1 or self.solicitud_externa[self.lugar - 1] != 0:
            print(f"Abrir puertas en el piso {self.lugar}")
            self.parar()  # El ascensor debe detenerse
            self.puertas_abiertas = True
            # Se simula el tiempo de abrir puertas
            time.sleep(1)  # 1 segundo para abrir puertas (ajustar según necesidad)

    def cerrar_puertas(self):
        if self.puertas_abiertas:
            print(f"Cerrar puertas en el piso {self.lugar}")
            self.puertas_abiertas = False
            # Simulamos el tiempo de cerrar puertas
            time.sleep(1)  # 1 segundo para cerrar puertas (ajustar según necesidad)
            # Actualiza el estado del ascensor después de cerrar las puertas
            if any(self.solicitud_interna) or any(self.solicitud_externa):
                if self.direccion == 1 and self.lugar < 5:
                    self.mover_arriba()
                elif self.direccion == -1 and self.lugar > 1:
                    self.mover_abajo()
                else:
                    self.parar()
            else:
                self.parar()
# Funcion para acutualizar el estado del ascensor
    def actualizar_estado(self, accion):
        if accion == "ARRIBA":
            self.mover_arriba()
        elif accion == "ABAJO":
            self.mover_abajo()
        elif accion == "PARAR":
            self.parar()
        elif accion == "ABRIR_PUERTAS":
            self.abrir_puertas()
        elif accion == "CERRAR_PUERTAS":
            self.cerrar_puertas()

# Definimos el ambiente de aprendizaje
class Ambiente:
    def __init__(self):
        self.ascensor = Ascensor()
        self.q_table = np.zeros((5, 3, 2, 2, 2, 2, 2, 5, 5, 5, 5, 5, 3))  # Inicializamos los vectores con ceros

    def obtener_estado(self):
        estado = [self.ascensor.lugar, self.ascensor.direccion, self.ascensor.movimiento] + \
                 self.ascensor.solicitud_interna + self.ascensor.solicitud_externa
        return tuple(estado)

    def ejecutar_accion(self, accion):
        self.ascensor.actualizar_estado(accion)
# Esto es parte del sistema de recompensas 
    def obtener_recompensa(self, accion):
        recompensa = 0
    # Recompensa por atender solicitudes internas
        for i in range(5):
            if self.ascensor.solicitud_interna[i] == 1 and self.ascensor.lugar == i + 1:
                recompensa += 10
                self.ascensor.solicitud_interna[i] = 0

        # Recompensa por atender solicitudes externas
        for i in range(5):
            if self.ascensor.solicitud_externa[i] != 0 and self.ascensor.lugar == i + 1:
                recompensa += 15
                self.ascensor.solicitud_externa[i] = 0
                self.ascensor.tiempo_espera_externa[i] = 0

        # Penalización por tiempo de espera de solicitudes externas
        for i in range(5):
            if self.ascensor.solicitud_externa[i] != 0:
                self.ascensor.tiempo_espera_externa[i] += 1
                recompensa -= self.ascensor.tiempo_espera_externa[i]

        # Penalización por cambio de dirección innecesario
        if accion == "UP" and self.ascensor.direccion == -1 and any(self.ascensor.solicitud_interna):
            recompensa -= 5
        if accion == "DOWN" and self.ascensor.direccion == 1 and any(self.ascensor.solicitud_interna):
            recompensa -= 5

        return recompensa
