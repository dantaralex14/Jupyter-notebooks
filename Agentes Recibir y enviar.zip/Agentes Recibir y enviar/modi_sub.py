# pubsub_hilos.py
import redis
import random
import time, json
import threading
import numpy as np
import math

ei = []
ai = []
R = 0
gamma = 0.75
alpha = 0.9
# Inicialización de los valores Q
Q = np.array(np.zeros([101,21]))
iterator = 0
action = 24
current_temp = 30
start = 0
key = 1

class Q_learning(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)
        print('Q_Learning')
    # modelo para entrenamiento
    
    def respond(self, Yk, Uk):
        return (Uk) + (Yk - (Uk)) * math.exp(-1.0/3.0)#+random.uniform(-0.3, 0.3)
        #return 0.79798315*Yk + 0.18809689*Uk + 0.33851755
        
    # Definición de los estados
    def estados(self):
        Y=20.0
        estados = []
        for k in range(101):
            Y=round(Y,1)
            estados.append(Y)
            Y=Y+0.1
        return estados
        #print(estados)
    
    # Definición de las acciones
    def acciones(self):
        A=20.0
        acciones = []
        for k in range(21):
            A=round(A,1)
            acciones.append(A)
            A=A+0.5
        return acciones
        #print(ai)
    
    # Definición de las recompensas
    def reward(self, temp):
        if ((temp > 23.5) and(temp < 24.5)):
            return 1.0
        else:
            return 0.0
    
    def Ambiente(self,ei,ai):
        y=self.respond(ei,ai)
        R_i1=self.reward(y)
        return y,R_i1
    
    def run(self):
        global ei, ai, Q, start, gamma, alpha
        ei = self.estados()
        ai = self.acciones()
        # Implementación del proceso de Q-Learning
        for i in range(100000):
            estado_actual = np.random.randint(0,101)
            accion_realizable = np.random.randint(0,21)
            temp_siguiente,Ri = self.Ambiente(ei[estado_actual], ai[accion_realizable])
            if (temp_siguiente > 30.0):
                temp_siguiente = 30.0
            if (temp_siguiente < 20.0):
                temp_siguiente = 20.0
            estado_siguiente =  ei.index(round(temp_siguiente,1))
            TD = Ri + gamma*Q[estado_siguiente, np.argmax(Q[estado_siguiente,])]- Q[estado_actual, accion_realizable]
            Q[estado_actual, accion_realizable] = Q[estado_actual, accion_realizable] + alpha*TD
        start = 1
        print('Q ', Q)

class Leer_Sensor(threading.Thread):
    def __init__(self, r1, channels):
        threading.Thread.__init__(self)
        self.redis,self.init = r1,0
        self.pubsub = self.redis.pubsub()
        print('Inicializado Subscriber...')
        try:
            self.pubsub.subscribe(channels)
        except Exception as e:
            print(e)

    def work(self, item):  	
        #global  definir aquí variables a comunicar entre hilos
        data: str 
        global current_temp   
        try:
            data = json.loads(str(item))
            current_temp = data['valor']
        except Exception as e:
            print(e)

    def run(self):
        for message in self.pubsub.listen():
            try:
                if message["type"] == "message":
                    #print(message)
                    self.work(message['data'])
                time.sleep(0.01)
            except ConnectionError:
                print('[lost connection]')
                while True:
                    print('trying to reconnect...')
                    try:
                        self.redis.ping()
                    except ConnectionError:
                        time.sleep(10)
                    else:
                        self.pubsub.subscribe(['canal1-1'])
                        break
            time.sleep(0.01)  # Esto es para darle tiempo al sistema :)

class Control(threading.Thread):
    def __init__(self,r2):
        global key, start, current_temp, ei, ai, Q
        threading.Thread.__init__(self)
        print('iniciando publisher')
        #json_datos ## Variable json a publicar
        while True:
            time.sleep(1) ### Este tiempo implementa un hilo peródico de 1 seg
            print('start pub ', start)
            try:
                if (start == 1):
                    estado_act =  ei.index(round(current_temp,1))
                    acc_sig = np.argmax(Q[estado_act,])
                    action = ai[acc_sig]
                    val = {
                        "id" : key,
                        "valor" : action
                    }
                    json_datos = json.dumps(val)
                    print(json_datos)
                    r2.publish("canal9-0",json_datos) ###
                    key = 0
            except Exception as e:
                print(e)

if __name__ == "__main__":
    global r

    qlearning = Q_learning()
    qlearning.start()
    try:
        r = redis.Redis(host='192.168.16.217', port=6379, db=0, charset="utf-8", decode_responses=True)
    except Exception as e:
        print(e)
    
    sub = Leer_Sensor(r,['canal9-1'])
    sub.start()
    pub = Control(r)
    pub.start()