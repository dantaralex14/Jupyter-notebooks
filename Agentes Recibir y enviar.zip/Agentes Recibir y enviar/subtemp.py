# subcriber.py

import redis
import time 
import json

r = redis.Redis(host='192.168.16.217',port=6379, db=0, charset='utf-8',
decode_responses=True)

#json_dato = data_str[]

p = r.pubsub()

p.subscribe("canal9-1")
data:str
while True:
    message = p.get_message()
    if message and 'data' in message:
        dato = str(message['data'])
        print(dato)
        ##Aqui pasamos la informacion a formato json
        with open('Data.txt', 'a') as archivo:
          archivo.write(dato + '\n')
          
    time.sleep(0.01)
