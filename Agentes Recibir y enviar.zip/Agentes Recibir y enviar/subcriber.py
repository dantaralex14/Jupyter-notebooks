# subcriber.py

import redis
import time
import json

r = redis.Redis(host='192.168.16.217',port=6379, db=0, charset='utf-8',
decode_responses=True)

p = r.pubsub()

json_datos = json.dumps({"id":0,"valor":1})
r.publish('canal9-0',json_datos)

#192.168.16.217